//
//  ProjectCell.h
//  CoverFlowMatrix
//
//  Created by James Rutherford on 2012-12-13.
//  Copyright (c) 2012 Braxio Interactive. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProjectCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *cellImage;


@end
